// ═══════════════════════════════════════════
//  NexusHire — Face Recognition JS
// ═══════════════════════════════════════════

let cameraActive = false;
let videoStream = null;
let verifyInterval = null;
let selectedFile = null;
let verifyLog = [];
let accuracyHistory = [];
let totalChecks = 0, successChecks = 0, failedChecks = 0;

const video = document.getElementById('videoFeed');
const canvas = document.createElement('canvas');

// ─── Upload Zone ──────────────────────────
const uploadZone = document.getElementById('uploadZone');
const fileInput = document.getElementById('faceFileInput');
const btnUpload = document.getElementById('btnUpload');

uploadZone.addEventListener('click', () => fileInput.click());

uploadZone.addEventListener('dragover', e => {
  e.preventDefault();
  uploadZone.classList.add('dragover');
});
uploadZone.addEventListener('dragleave', () => uploadZone.classList.remove('dragover'));
uploadZone.addEventListener('drop', e => {
  e.preventDefault();
  uploadZone.classList.remove('dragover');
  const file = e.dataTransfer.files[0];
  if (file && file.type.startsWith('image/')) handleFileSelect(file);
});

fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) handleFileSelect(fileInput.files[0]);
});

function handleFileSelect(file) {
  selectedFile = file;
  btnUpload.disabled = false;

  const reader = new FileReader();
  reader.onload = e => {
    const preview = document.getElementById('uploadPreview');
    const previewImg = document.getElementById('previewImg');
    previewImg.src = e.target.result;
    uploadZone.style.display = 'none';
    preview.style.display = 'block';

    const status = document.getElementById('previewStatus');
    status.innerHTML = `<div class="ps-dots"><span></span><span></span><span></span></div> Face detected`;
  };
  reader.readAsDataURL(file);
}

btnUpload.addEventListener('click', async () => {
  if (!selectedFile) return;

  btnUpload.disabled = true;
  btnUpload.innerHTML = '<div class="ps-dots"><span></span><span></span><span></span></div> Uploading...';

  const formData = new FormData();
  formData.append('image', selectedFile);

  try {
    const res = await fetch('/api/upload-face', { method: 'POST', body: formData });
    const data = await res.json();

    const statusEl = document.getElementById('uploadStatus');
    if (data.success) {
      statusEl.className = 'upload-status success';
      statusEl.textContent = '✓ ' + data.message;
      document.getElementById('btnCamera').disabled = false;
      document.getElementById('cameraPlaceholder').innerHTML = `
        <div class="cp-icon" style="color:var(--accent-green);opacity:0.6">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1"><path d="M9 11l3 3L22 4"/></svg>
        </div>
        <p style="color:var(--accent-green)">Face Registered</p>
        <span>Click "Start Camera" to begin verification</span>
      `;
    } else {
      statusEl.className = 'upload-status error';
      statusEl.textContent = '✗ ' + data.error;
      // Reset to allow retry
      document.getElementById('uploadPreview').style.display = 'none';
      uploadZone.style.display = 'flex';
      selectedFile = null;
    }
  } catch (err) {
    const statusEl = document.getElementById('uploadStatus');
    statusEl.className = 'upload-status error';
    statusEl.textContent = '✗ Network error. Try again.';
  }

  btnUpload.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg> Upload & Register Face`;
  btnUpload.disabled = false;
});

// ─── Camera Controls ──────────────────────
async function toggleCamera() {
  if (cameraActive) {
    stopCamera();
  } else {
    await startCamera();
  }
}

async function startCamera() {
  try {
    videoStream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'user' }
    });
    video.srcObject = videoStream;
    video.style.display = 'block';

    document.getElementById('cameraPlaceholder').style.display = 'none';
    document.getElementById('faceOverlay').style.display = 'block';
    document.getElementById('matchHud').style.display = 'flex';

    cameraActive = true;
    const btn = document.getElementById('btnCamera');
    btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18.36 6.64A9 9 0 0 1 20.77 15"/><path d="M6.16 6.16a9 9 0 1 0 12.68 12.68"/><path d="M12 2v4M2 12h4M12 22v-4M22 12h-4"/></svg> Stop Camera`;
    btn.classList.add('active');
    document.getElementById('btnCapture').disabled = false;

    // Auto-verify every 2 seconds
    verifyInterval = setInterval(autoVerify, 2000);
  } catch (err) {
    alert('Camera access denied or unavailable. Please allow camera permissions.');
  }
}

function stopCamera() {
  if (videoStream) {
    videoStream.getTracks().forEach(t => t.stop());
    videoStream = null;
  }
  video.style.display = 'none';
  document.getElementById('cameraPlaceholder').style.display = 'flex';
  document.getElementById('faceOverlay').style.display = 'none';
  document.getElementById('matchHud').style.display = 'none';

  clearInterval(verifyInterval);
  cameraActive = false;

  const btn = document.getElementById('btnCamera');
  btn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 7l-7 5 7 5V7zM1 5h15a2 2 0 012 2v10a2 2 0 01-2 2H1a2 2 0 01-2-2V7a2 2 0 012-2z"/></svg> Start Camera`;
  btn.classList.remove('active');
  document.getElementById('btnCapture').disabled = true;
}

function captureFrame() {
  if (!video.videoWidth) return null;
  canvas.width = video.videoWidth;
  canvas.height = video.videoHeight;
  const ctx = canvas.getContext('2d');
  ctx.drawImage(video, 0, 0);
  return canvas.toDataURL('image/jpeg', 0.7);
}

async function captureAndVerify() {
  const frame = captureFrame();
  if (!frame) { alert('Camera not ready.'); return; }
  await sendVerify(frame, true);
}

async function autoVerify() {
  const frame = captureFrame();
  if (!frame) return;
  await sendVerify(frame, false);
}

async function sendVerify(frameData, logEntry) {
  try {
    const res = await fetch('/api/verify-face', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ frame: frameData })
    });
    const data = await res.json();

    if (data.success) {
      updateHUD(data);
      if (logEntry && data.face_detected) {
        addLogEntry(data);
        updateStats(data);
        updateAccuracyChart(data.accuracy);
      }
    }
  } catch (err) {
    // Silently handle
  }
}

function updateHUD(data) {
  const hud = document.getElementById('matchHud');
  const ringFill = document.getElementById('hudRingFill');
  const hudAcc = document.getElementById('hudAccuracy');
  const hsIcon = document.getElementById('hsIcon');
  const hsText = document.getElementById('hsText');

  if (!data.face_detected) {
    hudAcc.textContent = '—';
    hsIcon.style.color = 'var(--text-muted)';
    hsText.textContent = 'No face detected';
    ringFill.style.strokeDashoffset = 157;
    ringFill.style.stroke = 'var(--text-muted)';
    return;
  }

  const acc = data.accuracy;
  const offset = 157 - (acc / 100) * 157;
  ringFill.style.strokeDashoffset = offset;
  hudAcc.textContent = acc + '%';

  if (data.match) {
    ringFill.style.stroke = 'var(--accent-green)';
    hsIcon.style.color = 'var(--accent-green)';
    hsIcon.textContent = '✓';
    hsText.textContent = `Identity Verified — ${acc}%`;
  } else {
    ringFill.style.stroke = '#ff6b6b';
    hsIcon.style.color = '#ff6b6b';
    hsIcon.textContent = '✗';
    hsText.textContent = `No Match — ${acc}%`;
  }
}

function addLogEntry(data) {
  const log = document.getElementById('vhLog');
  const emptyEl = log.querySelector('.vh-empty');
  if (emptyEl) emptyEl.remove();

  const now = new Date();
  const time = now.toLocaleTimeString('en-US', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' });

  const entry = document.createElement('div');
  entry.className = `vh-entry ${data.match ? 'match' : 'no-match'}`;
  entry.innerHTML = `
    <span class="ve-time">${time}</span>
    <span>${data.match ? '✓ Match' : '✗ No Match'}</span>
    <span class="ve-acc">${data.accuracy}%</span>
  `;
  log.insertBefore(entry, log.firstChild);

  // Keep max 8 entries
  const entries = log.querySelectorAll('.vh-entry');
  if (entries.length > 8) entries[entries.length - 1].remove();
}

function updateStats(data) {
  totalChecks++;
  if (data.match) successChecks++;
  else failedChecks++;

  document.getElementById('totalChecks').textContent = totalChecks;
  document.getElementById('successChecks').textContent = successChecks;
  document.getElementById('failedChecks').textContent = failedChecks;

  accuracyHistory.push(data.accuracy);
  const avg = Math.round(accuracyHistory.reduce((a, b) => a + b, 0) / accuracyHistory.length);
  document.getElementById('avgAccuracy').textContent = avg + '%';

  // Update identity status
  const statusVal = document.getElementById('isValue');
  const indicator = document.getElementById('isIndicator');
  if (data.match) {
    statusVal.textContent = 'Verified';
    statusVal.style.color = 'var(--accent-green)';
    indicator.className = 'is-indicator verified';
  } else {
    statusVal.textContent = 'Not Matched';
    statusVal.style.color = '#ff6b6b';
    indicator.className = 'is-indicator failed';
  }
}

function updateAccuracyChart(acc) {
  const container = document.getElementById('acBars');
  const emptyEl = container.querySelector('.ac-empty');
  if (emptyEl) emptyEl.remove();

  const color = acc >= 80 ? 'var(--accent-green)' : acc >= 50 ? 'var(--accent-orange)' : '#ff6b6b';
  const bar = document.createElement('div');
  bar.className = 'ac-bar';
  const height = Math.max(4, Math.round((acc / 100) * 64));
  bar.style.cssText = `height:${height}px; background:${color}; opacity:0.75;`;
  bar.dataset.val = acc;
  container.appendChild(bar);

  // Keep max 20 bars
  const bars = container.querySelectorAll('.ac-bar');
  if (bars.length > 20) bars[0].remove();
}
