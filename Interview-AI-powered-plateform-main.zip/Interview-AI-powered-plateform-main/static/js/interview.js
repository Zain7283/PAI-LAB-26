// ═══════════════════════════════════════════
//  NexusHire — Interview Page JS
// ═══════════════════════════════════════════

let currentQuestion = null;
let selectedCategory = document.querySelector('.cat-btn.active')?.dataset.category || 'Python Programming';
let sessionScores = [];
let questionsAnswered = 0;
let sessionStartTime = Date.now();
let timerInterval = null;
let questionTimerInterval = null;
let questionTimeLeft = 120;

// ─── Session Timer ────────────────────────
setInterval(() => {
  const elapsed = Math.floor((Date.now() - sessionStartTime) / 1000);
  const m = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const s = String(elapsed % 60).padStart(2, '0');
  const el = document.getElementById('sessionTime');
  if (el) el.textContent = `${m}:${s}`;
}, 1000);

// ─── Category Selection ───────────────────
document.querySelectorAll('.cat-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    selectedCategory = btn.dataset.category;
  });
});

// ─── Answer character count ───────────────
const answerInput = document.getElementById('answerInput');
if (answerInput) {
  answerInput.addEventListener('input', () => {
    const len = answerInput.value.length;
    const el = document.getElementById('charCount');
    if (el) el.textContent = `${len} character${len !== 1 ? 's' : ''}`;
  });
}

// ─── Get Question ─────────────────────────
async function getQuestion() {
  showLoading('Generating your question...');
  setStatus('loading', 'Generating...');

  // Reset UI
  document.getElementById('resultsPanel').style.display = 'none';
  document.getElementById('answerSection').style.display = 'none';
  document.getElementById('questionMeta').style.display = 'none';
  if (answerInput) answerInput.value = '';
  const charEl = document.getElementById('charCount');
  if (charEl) charEl.textContent = '0 characters';

  try {
    const res = await fetch('/api/get-question', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ category: selectedCategory })
    });
    const data = await res.json();

    if (data.success) {
      currentQuestion = data.data;
      displayQuestion(currentQuestion);
      startQuestionTimer(currentQuestion.time_limit || 120);
      setStatus('active', `${selectedCategory} Interview`);
    } else {
      showError(data.error || 'Failed to generate question');
      setStatus('', 'Error — Try again');
    }
  } catch (err) {
    showError('Network error. Please check your connection.');
    setStatus('', 'Connection Error');
  } finally {
    hideLoading();
  }
}

function displayQuestion(q) {
  const display = document.getElementById('questionDisplay');
  display.innerHTML = `<div class="question-text">${q.question}</div>`;

  const metaTags = document.getElementById('metaTags');
  const diffClass = `difficulty-${q.difficulty?.toLowerCase() || 'medium'}`;
  metaTags.innerHTML = `
    <span class="meta-tag ${diffClass}">${q.difficulty || 'Medium'}</span>
    <span class="meta-tag category">${q.category}</span>
    ${(q.expected_topics || []).slice(0, 3).map(t => `<span class="meta-tag topic">${t}</span>`).join('')}
  `;

  document.getElementById('questionMeta').style.display = 'flex';
  document.getElementById('answerSection').style.display = 'block';
  document.getElementById('btnSubmit').disabled = false;
}

// ─── Question Timer ───────────────────────
function startQuestionTimer(seconds) {
  clearInterval(questionTimerInterval);
  questionTimeLeft = seconds;
  updateTimerDisplay();

  questionTimerInterval = setInterval(() => {
    questionTimeLeft--;
    updateTimerDisplay();
    if (questionTimeLeft <= 0) {
      clearInterval(questionTimerInterval);
    }
  }, 1000);
}

function updateTimerDisplay() {
  const m = String(Math.floor(questionTimeLeft / 60)).padStart(2, '0');
  const s = String(questionTimeLeft % 60).padStart(2, '0');
  const el = document.getElementById('questionTimer');
  if (el) {
    el.textContent = `${m}:${s}`;
    el.style.color = questionTimeLeft < 30 ? '#ff6b6b' : '';
  }
}

// ─── Submit Answer ────────────────────────
async function submitAnswer() {
  const answer = document.getElementById('answerInput')?.value?.trim();
  if (!answer || answer.length < 10) {
    alert('Please provide a more detailed answer (at least 10 characters).');
    return;
  }
  if (!currentQuestion) {
    alert('Please generate a question first.');
    return;
  }

  showLoading('AI is evaluating your answer...');
  document.getElementById('btnSubmit').disabled = true;
  clearInterval(questionTimerInterval);

  try {
    const res = await fetch('/api/submit-answer', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        question: currentQuestion.question,
        answer,
        expected_topics: currentQuestion.expected_topics || []
      })
    });
    const data = await res.json();

    if (data.success) {
      displayResults(data.data);
      updateSessionStats(data.data.overall_score);
    } else {
      showError(data.error || 'Evaluation failed');
      document.getElementById('btnSubmit').disabled = false;
    }
  } catch (err) {
    showError('Network error during evaluation.');
    document.getElementById('btnSubmit').disabled = false;
  } finally {
    hideLoading();
  }
}

function displayResults(result) {
  document.getElementById('resultsPanel').style.display = 'block';
  document.getElementById('resultsPanel').scrollIntoView({ behavior: 'smooth', block: 'start' });

  // Verdict badge
  const vb = document.getElementById('verdictBadge');
  vb.textContent = result.verdict;
  vb.className = `verdict-badge verdict-${result.verdict}`;

  // Animate score rings
  const circumference = 213.6;
  setTimeout(() => {
    animateRing('accuracyRing', result.accuracy_score, circumference);
    animateRing('technicalRing', result.technical_score, circumference);
    animateRing('commsRing', result.communication_score, circumference);
    animateRing('overallRing', result.overall_score, circumference);

    animateNumber('accuracyScore', result.accuracy_score);
    animateNumber('technicalScore', result.technical_score);
    animateNumber('commsScore', result.communication_score);
    animateNumber('overallScore', result.overall_score);
  }, 100);

  // Grade badge in overall
  document.getElementById('overallScore').innerHTML = `${result.overall_score}<small style="font-size:0.5em;display:block;color:var(--accent-orange)">${result.grade}</small>`;

  // Lists
  renderList('strengthsList', result.strengths || []);
  renderList('improvementsList', result.improvements || []);

  // Topic Coverage
  const topicsDiv = document.getElementById('topicsCovered');
  topicsDiv.innerHTML = '';
  const allTopics = (currentQuestion?.expected_topics || []);
  allTopics.forEach(t => {
    const isCovered = (result.covered_topics || []).some(ct => ct.toLowerCase().includes(t.toLowerCase().slice(0,5)));
    topicsDiv.innerHTML += `
      <div class="topic-item">
        <span class="topic-name">${t}</span>
        <span class="topic-status ${isCovered ? 'covered' : 'missing'}">${isCovered ? '✓ Covered' : '✗ Missing'}</span>
      </div>`;
  });

  document.getElementById('feedbackText').textContent = result.detailed_feedback || '';
  document.getElementById('hintText').textContent = result.model_answer_hints || '';
}

function animateRing(id, score, circumference) {
  const el = document.getElementById(id);
  if (!el) return;
  const offset = circumference - (score / 100) * circumference;
  el.style.strokeDashoffset = offset;
}

function animateNumber(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  let current = 0;
  const step = target / 40;
  const interval = setInterval(() => {
    current = Math.min(current + step, target);
    el.textContent = Math.round(current);
    if (current >= target) clearInterval(interval);
  }, 30);
}

function renderList(id, items) {
  const el = document.getElementById(id);
  if (!el) return;
  el.innerHTML = items.map(item => `<li>${item}</li>`).join('');
}

// ─── Session Stats ────────────────────────
function updateSessionStats(score) {
  questionsAnswered++;
  sessionScores.push(score);

  const el = document.getElementById('questionsAnswered');
  if (el) el.textContent = questionsAnswered;

  const avg = Math.round(sessionScores.reduce((a, b) => a + b, 0) / sessionScores.length);
  const avgEl = document.getElementById('avgScore');
  if (avgEl) avgEl.textContent = avg + '%';

  renderScoreBars();
}

function renderScoreBars() {
  const container = document.getElementById('scoreBars');
  if (!container) return;
  const colors = ['#00ff88', '#00cfff', '#a78bfa', '#fb923c', '#ff6b6b'];
  const max = Math.max(...sessionScores, 1);
  container.innerHTML = sessionScores.map((s, i) => {
    const h = Math.round((s / 100) * 64);
    const color = s >= 80 ? '#00ff88' : s >= 60 ? '#00cfff' : s >= 40 ? '#fb923c' : '#ff6b6b';
    return `<div class="sh-bar" style="height:${h}px; background:${color}; opacity:0.7;" title="${s}%"></div>`;
  }).join('');
}

// ─── Status ───────────────────────────────
function setStatus(type, text) {
  const dot = document.getElementById('statusDot');
  const label = document.getElementById('statusText');
  if (dot) { dot.className = 'status-indicator' + (type ? ` ${type}` : ''); }
  if (label) label.textContent = text;
}

// ─── Loading ──────────────────────────────
function showLoading(msg) {
  const overlay = document.getElementById('loadingOverlay');
  const text = document.getElementById('loadingText');
  if (overlay) overlay.classList.add('active');
  if (text) text.textContent = msg;
}
function hideLoading() {
  const overlay = document.getElementById('loadingOverlay');
  if (overlay) overlay.classList.remove('active');
}
function showError(msg) {
  alert('Error: ' + msg);
}
