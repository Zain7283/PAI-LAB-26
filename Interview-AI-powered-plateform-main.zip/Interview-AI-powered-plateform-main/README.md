# NexusHire — AI Interview Platform

A professional AI-powered interview platform with real-time question generation, answer evaluation, and biometric face verification.

## Features
- **AI Interview Module** — Gemini AI generates unique questions per session, evaluates answers with detailed scoring
- **Face Verification Module** — Upload reference photo, live camera matching with accuracy percentage
- **Beautiful Dark UI** — Professional design with Syne + DM Sans typography

---

## Setup Instructions

### 1. Install System Dependencies

**For face_recognition (requires dlib):**
```bash
# Ubuntu/Debian
sudo apt-get update
sudo apt-get install -y cmake build-essential libopenblas-dev liblapack-dev libx11-dev libgtk-3-dev

# macOS
brew install cmake dlib
```

### 2. Install Python Dependencies
```bash
pip install -r requirements.txt
```

> Note: `face_recognition` may take a few minutes to install as it compiles dlib.

### 3. Set Your Gemini API Key
```bash
export GEMINI_API_KEY="your_gemini_api_key_here"
```

Get your free API key at: https://aistudio.google.com/app/apikey

### 4. Run the Application
```bash
python app.py
```

Visit: **http://localhost:5000**

---

## Project Structure
```
interview_platform/
├── app.py                    # Flask backend
├── requirements.txt
├── templates/
│   ├── base.html             # Base layout + navbar
│   ├── index.html            # Landing page
│   ├── interview.html        # Interview session page
│   └── face_recognition.html # Face ID page
└── static/
    ├── css/style.css         # Complete styling
    ├── js/
    │   ├── main.js           # Global JS
    │   ├── interview.js      # Interview logic
    │   └── face_recognition.js # Face ID logic
    └── uploads/              # Face reference photos (auto-created)
```

---

## API Endpoints
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/` | Landing page |
| GET | `/interview` | Interview session |
| GET | `/face-recognition` | Face ID page |
| POST | `/api/get-question` | Generate AI question |
| POST | `/api/submit-answer` | Evaluate answer |
| POST | `/api/upload-face` | Register reference face |
| POST | `/api/verify-face` | Live face verification |

---

## Troubleshooting

**`face_recognition` install fails:**
- Make sure cmake and dlib system deps are installed first
- Try: `pip install dlib --verbose` then `pip install face_recognition`

**Camera not working:**
- Allow camera permissions in browser
- Use HTTPS or localhost (required for camera API)

**Gemini API errors:**
- Verify your API key is set correctly
- Check quota at https://aistudio.google.com
