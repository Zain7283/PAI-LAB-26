import google.generativeai as genai

genai.configure(api_key="AIzaSyCx5M8tZbpLlBJI9osV36qbKzNMW4XAaFQ")

model = genai.GenerativeModel("gemini-2.5-flash")

response = model.generate_content("Hello")
print(response.text)