from flask import Flask, render_template, request, jsonify, session
import google.generativeai as genai
import os
import base64
import cv2
import numpy as np
import uuid
import json
import tempfile
from deepface import DeepFace
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.urandom(24)

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyCdhAJ1mxaEZF1fUFw8dTYxYsz-rq1v5hA")
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel("gemini-2 flash")

INTERVIEW_CATEGORIES = [
    "Python Programming", "JavaScript", "Data Structures & Algorithms",
    "System Design", "Machine Learning", "Web Development",
    "Database Design", "Cloud Computing", "DevOps", "Behavioral"
]


def generate_question(category="Software Engineering"):
    prompt = f"""Generate a unique, challenging interview question for the category: {category}.
    
    Return ONLY a JSON object with this exact structure:
    {{
        "question": "The interview question here",
        "category": "{category}",
        "difficulty": "Easy/Medium/Hard",
        "expected_topics": ["topic1", "topic2", "topic3"],
        "time_limit": 120
    }}
    
    Make it specific, technical, and different from common questions. No markdown, just JSON."""
    
    response = model.generate_content(prompt)
    text = response.text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    return json.loads(text.strip())


def evaluate_answer(question, answer, expected_topics):
    prompt = f"""You are an expert technical interviewer. Evaluate this interview answer.

Question: {question}
Candidate's Answer: {answer}
Expected Topics to Cover: {', '.join(expected_topics)}

Provide a detailed evaluation as a JSON object with this EXACT structure:
{{
    "accuracy_score": <integer 0-100>,
    "technical_score": <integer 0-100>,
    "communication_score": <integer 0-100>,
    "overall_score": <integer 0-100>,
    "grade": "<A+/A/B+/B/C+/C/D/F>",
    "strengths": ["strength1", "strength2"],
    "improvements": ["improvement1", "improvement2"],
    "missing_topics": ["topic1", "topic2"],
    "covered_topics": ["topic1"],
    "detailed_feedback": "Comprehensive paragraph feedback here",
    "model_answer_hints": "Brief hints about what an ideal answer would include",
    "verdict": "<Excellent/Good/Average/Below Average/Poor>"
}}

Be strict but fair. No markdown, just JSON."""

    response = model.generate_content(prompt)
    text = response.text.strip()
    if text.startswith("```"):
        text = text.split("```")[1]
        if text.startswith("json"):
            text = text[4:]
    return json.loads(text.strip())


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/interview')
def interview():
    return render_template('interview.html', categories=INTERVIEW_CATEGORIES)


@app.route('/face-recognition')
def face_rec():
    return render_template('face_recognition.html')


@app.route('/api/get-question', methods=['POST'])
def get_question():
    try:
        data = request.json
        category = data.get('category', 'Software Engineering')
        question_data = generate_question(category)
        session['current_question'] = question_data
        return jsonify({'success': True, 'data': question_data})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/submit-answer', methods=['POST'])
def submit_answer():
    try:
        data = request.json
        question = data.get('question')
        answer = data.get('answer')
        expected_topics = data.get('expected_topics', [])
        
        if not answer or len(answer.strip()) < 10:
            return jsonify({'success': False, 'error': 'Answer too short'}), 400
        
        evaluation = evaluate_answer(question, answer, expected_topics)
        return jsonify({'success': True, 'data': evaluation})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/upload-face', methods=['POST'])
def upload_face():
    try:
        if 'image' not in request.files:
            return jsonify({'success': False, 'error': 'No image provided'}), 400

        file = request.files['image']
        filename = f"ref_{uuid.uuid4().hex}.jpg"
        filepath = os.path.join(UPLOAD_FOLDER, filename)
        file.save(filepath)

        # Verify a face exists in the image using DeepFace
        try:
            faces = DeepFace.extract_faces(img_path=filepath, enforce_detection=True)
            if not faces:
                os.remove(filepath)
                return jsonify({'success': False, 'error': 'No face detected. Please use a clear frontal photo.'}), 400
        except Exception as e:
            os.remove(filepath)
            return jsonify({'success': False, 'error': 'No face detected. Please use a clear frontal photo.'}), 400

        # Store the filepath in session for later comparison
        session['face_image_path'] = filepath
        session['face_image'] = filename

        return jsonify({'success': True, 'message': 'Face registered successfully!', 'filename': filename})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/verify-face', methods=['POST'])
def verify_face():
    try:
        data = request.json
        frame_data = data.get('frame')

        if not frame_data:
            return jsonify({'success': False, 'error': 'No frame data'}), 400

        if 'face_image_path' not in session:
            return jsonify({'success': False, 'error': 'No reference face registered'}), 400

        ref_path = session['face_image_path']
        if not os.path.exists(ref_path):
            return jsonify({'success': False, 'error': 'Reference image not found. Please re-upload.'}), 400

        # Decode the base64 camera frame and save as temp file
        img_data = base64.b64decode(frame_data.split(',')[1])
        np_arr = np.frombuffer(img_data, np.uint8)
        frame = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)

        tmp_path = os.path.join(UPLOAD_FOLDER, f"tmp_{uuid.uuid4().hex}.jpg")
        cv2.imwrite(tmp_path, frame)

        try:
            result = DeepFace.verify(
                img1_path=ref_path,
                img2_path=tmp_path,
                model_name='VGG-Face',
                enforce_detection=False,
                silent=True
            )

            distance = float(result.get('distance', 1.0))
            threshold = float(result.get('threshold', 0.4))
            verified = bool(result.get('verified', False))

            # Convert distance to accuracy percentage
            # distance=0 means perfect match, distance >= threshold means no match
            accuracy = max(0, min(100, round((1 - distance / max(threshold * 2, 0.01)) * 100, 1)))

            os.remove(tmp_path)
            return jsonify({
                'success': True,
                'face_detected': True,
                'match': verified,
                'accuracy': accuracy,
                'distance': distance,
                'message': f'{"✓ Identity Verified" if verified else "✗ Identity Not Matched"} — {accuracy}% match'
            })

        except Exception as e:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            # No face detected in camera frame
            return jsonify({
                'success': True,
                'face_detected': False,
                'match': False,
                'accuracy': 0,
                'message': 'No face detected in camera'
            })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


if __name__ == '__main__':
    app.run(debug=True, port=5000)