from flask import Flask, render_template, request

app = Flask(__name__)

responses = {
    "hello": "Hello! Welcome to University Admission Chatbot.",
    "admission": "Admissions are open for Fall 2026.",
    "deadline": "The last date to apply is 30 September 2026.",
    "programs": "We offer BSCS, BBA, BSIT, and Engineering programs.",
    "fee": "The average semester fee is 85,000 PKR.",
    "bye": "Thank you for visiting."
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot():
    user_message = request.form["msg"].lower()

    for key in responses:
        if key in user_message:
            return responses[key]

    return "Sorry, I do not understand your question."

if __name__ == "__main__":
    app.run(debug=True)
