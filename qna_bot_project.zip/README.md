# Programming for Artificial Intelligence - Lab 12

## QnA Bot using Flask + MiniLM + FAISS

### Steps to Run
1. Install requirements:
   pip install -r requirements.txt

2. Run the application:
   python app.py

3. Open browser:
   http://127.0.0.1:5000

### Technologies Used
- Flask
- Sentence Transformers
- FAISS
- NumPy
