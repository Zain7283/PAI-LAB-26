from flask import Flask, request, jsonify, render_template
from sentence_transformers import SentenceTransformer
import faiss, numpy as np, json

app = Flask(__name__)

# Load dataset
with open('data/qna.json', 'r') as f:
    qna_data = json.load(f)

questions = [item['question'] for item in qna_data]
answers = [item['answer'] for item in qna_data]

# Load MiniLM model
model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# Create embeddings
embeddings = model.encode(questions, show_progress_bar=True)
embeddings = np.array(embeddings).astype('float32')

# Build FAISS index
index = faiss.IndexFlatL2(embeddings.shape[1])
index.add(embeddings)

@app.route('/search', methods=['POST'])
def search():
    query = request.json.get('query', '')
    q_emb = model.encode([query]).astype('float32')
    D, I = index.search(q_emb, 3)

    results = [
        {
            'question': questions[i],
            'answer': answers[i],
            'score': float(D[0][j])
        }
        for j, i in enumerate(I[0])
    ]

    return jsonify(results)

@app.route('/')
def home():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
